//
//  BT_CustomGraphicsTests.swift
//  BT_CustomGraphicsTests
//
//  Created by Brock Terry on 12/2/24.
//

import Testing
@testable import BT_CustomGraphics

struct BT_CustomGraphicsTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
