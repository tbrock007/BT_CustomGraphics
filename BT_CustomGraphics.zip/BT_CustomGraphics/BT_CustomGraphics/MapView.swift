//
//  MapView.swift
//  BT_CustomGraphics
//
//  Created by Brock Terry on 12/2/24.
//
import UIKit

class MapView: UIView {
    // MARK: - Properties
    var worldMap: [[String]] = [] // 2D array for the map tiles
    var playerPosition: (row: Int, col: Int) = (0, 0) // Player's position on the map
    let tileSize: CGSize = CGSize(width: 50, height: 50) // Size of each tile

    // MARK: - Drawing
    override func draw(_ rect: CGRect) {
        guard !worldMap.isEmpty else { return }

        for (row, rowArray) in worldMap.enumerated() {
            for (col, tile) in rowArray.enumerated() {
                let x = CGFloat(col) * tileSize.width
                let y = CGFloat(row) * tileSize.height
                let tileRect = CGRect(x: x, y: y, width: tileSize.width, height: tileSize.height)

                // Draw the tile
                let tileImage = imageForTile(tile: tile)
                tileImage.draw(in: tileRect)

                // Draw the player character if at this position
                if row == playerPosition.row && col == playerPosition.col {
                    let playerImage = UIImage(named: "person")!
                    playerImage.draw(in: tileRect)
                }
            }
        }
    }

    // MARK: - Helper Method
    func imageForTile(tile: String) -> UIImage {
        switch tile {
        case "M": return UIImage(named: "mountain")! // mountain.png in Assets
        case "f": return UIImage(named: "forest")!   // forest.png in Assets
        case "~": return UIImage(named: "water")!    // water.png in Assets
        case ".": return UIImage(named: "plain")!    // plain.png in Assets
        case "X": return UIImage(named: "treasure")! // treasure.png in Assets
        default: return UIImage(named: "out")!       // out.png in Assets
        }
    }
}
